import 'package:flutter_test/flutter_test.dart';
import 'package:masit/main.dart';
import 'package:flutter/material.dart';

void main() {
  testWidgets('App smoke test', (WidgetTester tester) async {
    await tester.pumpWidget(const MasitApp());

    // Verify that the app starts with the search bar
    expect(find.byType(TextField), findsOneWidget);

    // Verify that category tabs are present
    expect(find.text('For you'), findsOneWidget);
    expect(find.text('New'), findsOneWidget);
    expect(find.text('Love'), findsOneWidget);

    // Verify bottom navigation items
    expect(find.text('Template'), findsOneWidget);
    expect(find.text('Create'), findsOneWidget);
  });
}
