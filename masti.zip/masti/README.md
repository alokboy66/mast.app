# Masit App

A beautiful photo and video editing app with templates and effects.

## Features

- Modern and sleek dark theme UI
- Template browsing and searching
- Category-based filtering
- Photo and video editing capabilities
- Custom effects and filters
- Social sharing features

## Setup Instructions

1. Install Flutter (https://flutter.dev/docs/get-started/install)

2. Clone this repository:
```bash
git clone [your-repo-url]
```

3. Install dependencies:
```bash
flutter pub get
```

4. Run the app:
```bash
flutter run
```

## Project Structure

- `lib/`
  - `main.dart` - App entry point
  - `screens/` - Main app screens
  - `widgets/` - Reusable UI components
  - `theme/` - App theme configuration

## Requirements

- Flutter SDK: >=2.19.0
- Dart SDK: >=2.19.0

## Dependencies

- provider: State management
- path_provider: File system access
- image_picker: Image selection
- photo_view: Image viewing capabilities
- video_player: Video playback
- camera: Camera access
- flutter_staggered_grid_view: Grid layout
- google_fonts: Custom fonts
